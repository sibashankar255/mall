package com.mindtree.MallBrand;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MallBrandApplicationTests {

	@Test
	void contextLoads() {
	}

}
