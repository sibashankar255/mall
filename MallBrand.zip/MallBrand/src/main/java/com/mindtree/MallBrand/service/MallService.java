package com.mindtree.MallBrand.service;

import java.util.List;

import com.mindtree.MallBrand.entity.Brand;
import com.mindtree.MallBrand.entity.Mall;
import com.mindtree.MallBrand.exception.service.ServiceException;
import com.mindtree.MallBrand.exception.service.custom.MallNotFoundException;

public interface MallService {

	Mall insertMall(Mall mall);

	List<Brand> displayBrands(long mallId) throws ServiceException;

}
