package com.mindtree.MallBrand.service.serviceImpl;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.MallBrand.entity.Brand;
import com.mindtree.MallBrand.entity.Mall;
import com.mindtree.MallBrand.exception.service.custom.MallNotFoundException;
import com.mindtree.MallBrand.repository.MallRepository;
import com.mindtree.MallBrand.service.MallService;

@Service
public class MallServiceImpl implements MallService
{
	@Autowired
	private MallRepository mallRepository;

	@Override
	public Mall insertMall(Mall mall) 
	{
		return mallRepository.save(mall);
	}

	@Override
	public List<Brand> displayBrands(long mallId) throws MallNotFoundException 
	{
		Mall mall = mallRepository.findById(mallId).orElseThrow(() -> new MallNotFoundException("Mall not found"));
		
		List<Brand> brandList = mall.getBrand().stream()
				.filter(arg0 -> arg0.getMarketPrice()>20000 && arg0.getDiscount()>0.05).collect(Collectors.toList());
		
		List<Brand> sortedList = brandList.stream()
				.sorted(Comparator.comparingDouble(Brand::getMarketPrice)
				.reversed())
				.collect(Collectors.toList());
		
		return sortedList;
	}

}