package com.mindtree.MallBrand.controller.handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.mindtree.MallBrand.dto.ErrorDTO;
import com.mindtree.MallBrand.dto.ResponseBody;
import com.mindtree.MallBrand.exception.ApplicationException;


@RestControllerAdvice
public class ControllerHandler 
{
	@Autowired
	MessageSource messageSource;

	@ExceptionHandler(ApplicationException.class)
	public ResponseEntity<?> errorHandler(Exception e)
	{
		return new ResponseEntity<ResponseBody<Void>>(
				new ResponseBody<Void>(null, new ErrorDTO(e.getMessage(), e.getCause()), "Error in Application", false)
				,HttpStatus.BAD_REQUEST);
	}


}
