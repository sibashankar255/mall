package com.mindtree.MallBrand.controller;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.MallBrand.dto.BrandDTO;
import com.mindtree.MallBrand.dto.MallDTO;
import com.mindtree.MallBrand.dto.ResponseBody;
import com.mindtree.MallBrand.entity.Mall;
import com.mindtree.MallBrand.exception.ApplicationException;
import com.mindtree.MallBrand.exception.service.ServiceException;
import com.mindtree.MallBrand.service.MallService;

@RestController
public class MallController 
{
	@Autowired
	private MallService mallService;
	
	@Autowired
	private ModelMapper modelMapper;
	
	
	@PostMapping("/insertMall")
	public ResponseEntity<?> insertMall(@RequestBody MallDTO mall)
	{
		return new ResponseEntity<ResponseBody<MallDTO>>(new ResponseBody<MallDTO>(
				modelMapper.map(mallService.insertMall(modelMapper.map(mall,Mall.class))
						,MallDTO.class),null,"Mall Added Successfully",true),HttpStatus.OK);
	}
	
	@GetMapping("/displayBrands/{mallId}")
	public ResponseEntity<?> displayBrands(@PathVariable long mallId) throws ApplicationException
	{
		return new ResponseEntity<ResponseBody<List<BrandDTO>>>(new ResponseBody<List<BrandDTO>>(
				modelMapper.map(mallService.displayBrands(mallId), new TypeToken<List<BrandDTO>>() {
				}.getType()), null, "Brands Found", true), HttpStatus.OK);
	}

}
