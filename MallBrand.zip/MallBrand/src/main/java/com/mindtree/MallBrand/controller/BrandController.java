package com.mindtree.MallBrand.controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.MallBrand.dto.BrandDTO;
import com.mindtree.MallBrand.dto.MallDTO;
import com.mindtree.MallBrand.dto.ResponseBody;
import com.mindtree.MallBrand.entity.Brand;
import com.mindtree.MallBrand.entity.Mall;
import com.mindtree.MallBrand.exception.ApplicationException;
import com.mindtree.MallBrand.exception.service.ServiceException;
import com.mindtree.MallBrand.service.BrandService;

@RestController
public class BrandController 
{
	@Autowired
	private BrandService brandService;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@PostMapping("/insertBrand")
	public ResponseEntity<?> insertBrand(@RequestBody BrandDTO brand)
	{
		return new ResponseEntity<ResponseBody<BrandDTO>>(new ResponseBody<BrandDTO>(
				modelMapper.map(brandService.insertBrand(modelMapper.map(brand,Brand.class))
						,BrandDTO.class),null,"Brand Added Successfully",true),HttpStatus.OK);
	}
	
	
	@PostMapping("/buyBrandForMall/{mallName}/{brandId}")
	public ResponseEntity<?> assignTrackToLead(@PathVariable String mallName, @PathVariable long brandId) throws ApplicationException
	{
		return new ResponseEntity<ResponseBody<Void>>(new ResponseBody<Void>(
				brandService.buyBrandForMall(mallName,brandId), null,"Bought brand for mall Successfully",true), HttpStatus.OK);
			
	}
	
	
	
	
	

}
