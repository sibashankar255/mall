package com.mindtree.MallBrand.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(value = Include.NON_NULL)
public class BrandDTO 
{
	private String brandName;
	private double marketPrice;
	private float discountAvailable;
	private float discount;
	
	public BrandDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public double getMarketPrice() {
		return marketPrice;
	}
	public void setMarketPrice(double marketPrice) {
		this.marketPrice = marketPrice;
	}
	public float getDiscountAvailable() {
		return discountAvailable;
	}
	public void setDiscountAvailable(float discountAvailable) {
		this.discountAvailable = discountAvailable;
	}
	public float getDiscount() {
		return discount;
	}
	public void setDiscount(float discount) {
		this.discount = discount;
	}
	
	

}
