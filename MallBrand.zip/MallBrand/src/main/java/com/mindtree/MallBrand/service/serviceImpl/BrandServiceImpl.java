package com.mindtree.MallBrand.service.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.MallBrand.entity.Brand;
import com.mindtree.MallBrand.entity.Mall;
import com.mindtree.MallBrand.exception.service.custom.BrandNotFoundException;
import com.mindtree.MallBrand.exception.service.custom.MallNotFoundException;
import com.mindtree.MallBrand.repository.BrandRepository;
import com.mindtree.MallBrand.repository.MallRepository;
import com.mindtree.MallBrand.service.BrandService;

@Service
public class BrandServiceImpl implements BrandService
{
	@Autowired
	private BrandRepository brandRepository;
	@Autowired
	private MallRepository mallRepository;

	@Override
	public Brand insertBrand(Brand brand) {
		return brandRepository.save(brand);
	}

	@Override
	public Void buyBrandForMall(String mallName, long brandId) throws MallNotFoundException, BrandNotFoundException 
	{
		Mall mall = mallRepository.findBymallName(mallName).orElseThrow(() -> new MallNotFoundException("Mall not found"));
		Brand brand = brandRepository.findById(brandId).orElseThrow(() -> new BrandNotFoundException("Brand not found"));
		
		double totalBrandValue = brand.getMarketPrice() - brand.getMarketPrice()*brand.getDiscount();
		
		double totalInvestmentDone = mall.getTotalInvestmentDone() + totalBrandValue;
		
		mallRepository.updateMallData(totalInvestmentDone,mall.getMallId());
		
		mall.getBrand().add(brand);
		brand.getMall().add(mall);
		brandRepository.save(brand);
		
		return null;
	}

}
