package com.mindtree.MallBrand.service;

import com.mindtree.MallBrand.entity.Brand;
import com.mindtree.MallBrand.exception.service.ServiceException;
import com.mindtree.MallBrand.exception.service.custom.MallNotFoundException;

public interface BrandService {

	Brand insertBrand(Brand brand);

	Void buyBrandForMall(String mallName, long brandId) throws ServiceException;

}
