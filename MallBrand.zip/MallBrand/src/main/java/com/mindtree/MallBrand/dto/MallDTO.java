package com.mindtree.MallBrand.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(value = Include.NON_NULL)
public class MallDTO 
{
	private String mallName;
	private double totalBudget;
	private double totalInvestmentDone;
	
	public MallDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getMallName() {
		return mallName;
	}
	public void setMallName(String mallName) {
		this.mallName = mallName;
	}
	public double getTotalBudget() {
		return totalBudget;
	}
	public void setTotalBudget(double totalBudget) {
		this.totalBudget = totalBudget;
	}
	public double getTotalInvestmentDone() {
		return totalInvestmentDone;
	}
	public void setTotalInvestmentDone(double totalInvestmentDone) {
		this.totalInvestmentDone = totalInvestmentDone;
	}
	
	

}
