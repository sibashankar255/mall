package com.mindtree.MallBrand.exception.service.custom;

import com.mindtree.MallBrand.exception.service.ServiceException;

public class MallNotFoundException extends ServiceException
{

	public MallNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MallNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public MallNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public MallNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MallNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

}