package com.mindtree.MallBrand.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Brand
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long brandId;
	
	private String brandName;
	private double marketPrice;
	private float discountAvailable;
	private float discount;
	
	@ManyToMany(fetch = FetchType.LAZY)
	private List<Mall> mall;

	public Brand() {
		super();
	}

	public long getBrandId() {
		return brandId;
	}

	public void setBrandId(long brandId) {
		this.brandId = brandId;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public double getMarketPrice() {
		return marketPrice;
	}

	public void setMarketPrice(double marketPrice) {
		this.marketPrice = marketPrice;
	}

	public float getDiscountAvailable() {
		return discountAvailable;
	}

	public void setDiscountAvailable(float discountAvailable) {
		this.discountAvailable = discountAvailable;
	}

	public float getDiscount() {
		return discount;
	}

	public void setDiscount(float discount) {
		this.discount = discount;
	}

	public List<Mall> getMall() {
		return mall;
	}

	public void setMall(List<Mall> mall) {
		this.mall = mall;
	}

	


}
