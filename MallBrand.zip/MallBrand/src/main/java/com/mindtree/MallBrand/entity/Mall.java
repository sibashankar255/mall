package com.mindtree.MallBrand.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Mall 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long mallId;
	
	private String mallName;
	private double totalBudget;
	private double totalInvestmentDone;
	
	@ManyToMany(fetch = FetchType.EAGER,cascade = CascadeType.PERSIST,mappedBy = "mall")
	private List<Brand> brand;

	public Mall() {
		super();
	}

	public long getMallId() {
		return mallId;
	}

	public void setMallId(long mallId) {
		this.mallId = mallId;
	}

	public String getMallName() {
		return mallName;
	}

	public void setMallName(String mallName) {
		this.mallName = mallName;
	}

	public double getTotalBudget() {
		return totalBudget;
	}

	public void setTotalBudget(double totalBudget) {
		this.totalBudget = totalBudget;
	}

	public double getTotalInvestmentDone() {
		return totalInvestmentDone;
	}

	public void setTotalInvestmentDone(double totalInvestmentDone) {
		this.totalInvestmentDone = totalInvestmentDone;
	}

	public List<Brand> getBrand() {
		return brand;
	}

	public void setBrand(List<Brand> brand) {
		this.brand = brand;
	}

	
	
}
